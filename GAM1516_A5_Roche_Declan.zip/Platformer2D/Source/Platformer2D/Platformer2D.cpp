// Copyright Epic Games, Inc. All Rights Reserved.

#include "Platformer2D.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Platformer2D, "Platformer2D" );
